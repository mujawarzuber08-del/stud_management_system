<?php
session_start();
include("connection.php");

if (isset($_POST['submit'])) {

    $username = $_POST['user'];
    $password = $_POST['pass'];

    $sql = "SELECT * FROM stud_management_system WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) == 1) {

        // ✅ SESSION CREATE
        $_SESSION['username'] = $username;

        // ✅ REDIRECT
        header("Location: dashboard.php");
        exit();

    } else {
        // ❌ WRONG LOGIN
        $_SESSION['error'] = "Invalid username or password";
        header("Location: index.php");
        exit();
    }
}
?>
