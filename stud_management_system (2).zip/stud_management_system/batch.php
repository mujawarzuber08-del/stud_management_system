<?php
session_start();
include("connection.php");

// Session check
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$success = '';
$error = '';

// -------------------
// Delete Batch
// -------------------
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    $sql = "DELETE FROM batch WHERE id=$id";
    if(mysqli_query($conn, $sql)){
        $success = "Batch deleted successfully!";
    } else {
        $error = "Error deleting batch: " . mysqli_error($conn);
    }
}

// -------------------
// Add Batch
// -------------------
if(isset($_POST['add_batch'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $start_date = mysqli_real_escape_string($conn, $_POST['start_date']);
    $end_date = mysqli_real_escape_string($conn, $_POST['end_date']);

    $sql = "INSERT INTO batch (name, start_date, end_date) VALUES ('$name','$start_date','$end_date')";
    if(mysqli_query($conn, $sql)){
        $success = "Batch added successfully!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// -------------------
// Fetch all batches
// -------------------
$batches = mysqli_query($conn, "SELECT * FROM batch ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Batch Management</title>
<link rel="stylesheet" href="batch.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<div class="main">
    <h2 class="page-title">📚 Batch Management</h2>

    <!-- Messages -->
    <?php if($success) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if($error) echo "<div class='alert alert-error'>$error</div>"; ?>

    <!-- Add Batch Form -->
    <div class="batch-card">
        <h3>Add New Batch</h3>
        <form method="post" class="batch-form">
            <label>Batch Name</label>
            <input type="text" name="name" placeholder="Enter Batch Name" required>

            <label>Start Date</label>
            <input type="date" name="start_date" required>

            <label>End Date</label>
            <input type="date" name="end_date" required>

            <button type="submit" name="add_batch">
                <i class="fas fa-plus"></i> Add Batch
            </button>
        </form>
    </div>

    <!-- Batches Table -->
    <div class="batch-card">
        <h3>Batch List</h3>
        <table class="batch-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Batch Name</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($batches) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($batches)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']); ?></td>
                            <td><?= htmlspecialchars($row['name']); ?></td>
                            <td><?= htmlspecialchars($row['start_date']); ?></td>
                            <td><?= htmlspecialchars($row['end_date']); ?></td>
                            <td>
                                <a href="batch.php?delete=<?= $row['id']; ?>" onclick="return confirm('Delete this batch?');" class="btn btn-danger">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" style="text-align:center;">No batches found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
