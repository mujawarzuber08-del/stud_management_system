<?php
session_start();
include("connection.php");

// Session check
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$success = '';
$error = '';

// Fetch current user info
$current_user = $_SESSION['username'];
$user_id_result = mysqli_query($conn, "SELECT * FROM users WHERE username='$current_user'");
$user_data = mysqli_fetch_assoc($user_id_result);

// -------------------
// Update Username
// -------------------
if(isset($_POST['update_username'])){
    $new_username = mysqli_real_escape_string($conn, $_POST['username']);

    // Check if username already exists
    $check = mysqli_query($conn, "SELECT * FROM users WHERE username='$new_username' AND id != {$user_data['id']}");
    if(mysqli_num_rows($check) > 0){
        $error = "Username already taken!";
    } else {
        if(mysqli_query($conn, "UPDATE users SET username='$new_username' WHERE id={$user_data['id']}")){
            $_SESSION['username'] = $new_username; // update session
            $success = "Username updated successfully!";
        } else {
            $error = "Error updating username: " . mysqli_error($conn);
        }
    }
}

// -------------------
// Update Password
// -------------------
if(isset($_POST['update_password'])){
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];

    if(password_verify($current_password, $user_data['password'])){
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        if(mysqli_query($conn, "UPDATE users SET password='$hashed_password' WHERE id={$user_data['id']}")){
            $success = "Password updated successfully!";
        } else {
            $error = "Error updating password: " . mysqli_error($conn);
        }
    } else {
        $error = "Current password is incorrect!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Account Settings</title>
<link rel="stylesheet" href="account.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<div class="main">
    <h2 class="page-title">⚙️ Account Settings</h2>

    <!-- Messages -->
    <?php if($success) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if($error) echo "<div class='alert alert-error'>$error</div>"; ?>

    <!-- Update Username -->
    <div class="account-card">
        <h3>Change Username</h3>
        <form method="post" class="account-form">
            <label>New Username</label>
            <input type="text" name="username" value="<?= htmlspecialchars($current_user); ?>" required>
            <button type="submit" name="update_username">
                <i class="fas fa-user-edit"></i> Update Username
            </button>
        </form>
    </div>

    <!-- Update Password -->
    <div class="account-card">
        <h3>Change Password</h3>
        <form method="post" class="account-form">
            <label>Current Password</label>
            <input type="password" name="current_password" placeholder="Enter Current Password" required>

            <label>New Password</label>
            <input type="password" name="new_password" placeholder="Enter New Password" required>

            <button type="submit" name="update_password">
                <i class="fas fa-key"></i> Update Password
            </button>
        </form>
    </div>
</div>

</body>
</html>
