<?php
session_start();
include("connection.php");

/* Session check */
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

/* Total Students */
$student_result = mysqli_query($conn, "SELECT COUNT(*) AS total_students FROM student");
$student = ['total_students' => 0];
if($student_result) $student = mysqli_fetch_assoc($student_result);

/* Total Teachers */
$teacher_result = mysqli_query($conn, "SELECT COUNT(*) AS total_teachers FROM student_teacher");
$teacher = ['total_teachers' => 0];
if($teacher_result) $teacher = mysqli_fetch_assoc($teacher_result);


/* Total Notices */
$notice_result = mysqli_query($conn, "SELECT COUNT(*) AS total_notices FROM notice");
$notice = ['total_notices' => 0];
if($notice_result) $notice = mysqli_fetch_assoc($notice_result);

/* SMS Balance */
$sms_balance = 9; // Replace with dynamic DB value if needed
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard - GPTS Education</title>
<link rel="stylesheet" href="dashboard-style.css"> <!-- new CSS file -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>


<div class="wrapper">

   <!-- Sidebar -->
   <div class="sidebar">
       <h2><i class="fas fa-graduation-cap"></i> GPTS</h2>
       <ul>
           <li class="active"><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
           <li><a href="students.php"><i class="fas fa-users"></i><span>Students</span></a></li>
           <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i><span>Teachers</span></a></li>
           <li><a href="batch.php"><i class="fas fa-layer-group"></i><span>Batch</span></a></li>
           <li><a href="exam.php"><i class="fas fa-clipboard-list"></i><span>Exam</span></a></li>
           <li><a href="notice.php"><i class="fas fa-bell"></i><span>Notice</span></a></li>
           <li><a href="users.php"><i class="fas fa-user-shield"></i><span>Users</span></a></li>
           <li><a href="account.php"><i class="fas fa-cog"></i><span>Account</span></a></li>
           <li class="logout"><a href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
       </ul>
   </div>

    <!-- Main Content -->
    <div class="main">

       <!-- Top bar -->
<div class="topbar">
    <div class="topbar-left">
        <a href="dashboard.php" class="system-name">GPTS Admin Dashboard</a>
    </div>
    <div class="topbar-right">
        <div class="user-info">
            <i class="fas fa-user"></i>
            <span class="username"><?= htmlspecialchars($_SESSION['username']); ?></span>
        </div>
        <div class="datetime">
            <i class="fas fa-calendar-alt"></i>
            <!-- This span is required for JS live update -->
            <span id="current-time"></span>
        </div>
    </div>
</div>

<!-- JS for live time -->
<script>
function updateTime() {
    const now = new Date();
    const options = { month: 'long', day: 'numeric', year: 'numeric' };
    const date = now.toLocaleDateString(undefined, options);

    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;

    const time = `${date} - ${hours}:${minutes} ${ampm}`;
    document.getElementById('current-time').textContent = time;
}

// Run once immediately, then update every second
updateTime();
setInterval(updateTime, 1000);
</script>

        <!-- Dashboard Cards -->
        <div class="cards">
            <div class="card blue">
                <i class="fas fa-users"></i>
                <h3>Total Students</h3>
                <p><?= $student['total_students']; ?></p>
                <span class="trend positive">+12%</span>
            </div>

            <div class="card green">
                <i class="fas fa-chalkboard-teacher"></i>
                <h3>Total Teachers</h3>
                <p><?= $teacher['total_teachers']; ?></p>
                <span class="trend positive">+3 new</span>
            </div>

            <div class="card orange">
                <i class="fas fa-sms"></i>
                <h3>SMS Balance</h3>
                <p><?= $sms_balance; ?></p>
                <span class="trend warning">Low Balance</span>
            </div>

            <div class="card purple">
                <i class="fas fa-bell"></i>
                <h3>Total Notices</h3>
                <p><?= $notice['total_notices']; ?></p>
                <span class="trend neutral">Active</span>
            </div>
        </div>

        <!-- College Image -->
        <div class="college-img-container">
             <img src="assets/images/gpts.jpg" alt="College Image" class="dashboard-image">
        </div>
    </div>
</div>

<script>
// Sidebar active menu
document.querySelectorAll('.sidebar ul li').forEach((li) => {
    li.addEventListener('click', function() {
        document.querySelector('.sidebar li.active').classList.remove('active');
        this.classList.add('active');
    });
});

// Optional: Auto refresh stats every 30 seconds
setInterval(function() { location.reload(); }, 30000);
</script>

</body>
</html>
