<?php
session_start();
include("connection.php");

// Session check
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$success = '';
$error = '';

// -------------------
// Delete Notice
// -------------------
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    $sql = "DELETE FROM notice WHERE id=$id";
    if(mysqli_query($conn, $sql)){
        $success = "Notice deleted successfully!";
    } else {
        $error = "Error deleting notice: " . mysqli_error($conn);
    }
}

// -------------------
// Add Notice
// -------------------
if(isset($_POST['add_notice'])){
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $notice_date = mysqli_real_escape_string($conn, $_POST['notice_date']);

    $sql = "INSERT INTO notice (title, description, notice_date) VALUES ('$title', '$description', '$notice_date')";
    if(mysqli_query($conn, $sql)){
        $success = "Notice added successfully!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// -------------------
// Fetch all notices
// -------------------
$notices = mysqli_query($conn, "SELECT * FROM notice ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notice Management</title>
<link rel="stylesheet" href="notice.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<div class="main">
    <h2 class="page-title">🔔 Notice Management</h2>

    <!-- Messages -->
    <?php if($success) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if($error) echo "<div class='alert alert-error'>$error</div>"; ?>

    <!-- Add Notice Form -->
    <div class="notice-card">
        <h3>Add New Notice</h3>
        <form method="post" class="notice-form">
            <label>Title</label>
            <input type="text" name="title" placeholder="Enter Notice Title" required>

            <label>Description</label>
            <textarea name="description" placeholder="Enter Description" required></textarea>

            <label>Date</label>
            <input type="date" name="notice_date" required>

            <button type="submit" name="add_notice">
                <i class="fas fa-plus"></i> Add Notice
            </button>
        </form>
    </div>

    <!-- Notices Table -->
    <div class="notice-card">
        <h3>Notice List</h3>
        <table class="notice-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($notices) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($notices)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']); ?></td>
                            <td><?= htmlspecialchars($row['title']); ?></td>
                            <td><?= htmlspecialchars($row['description']); ?></td>
                            <td><?= htmlspecialchars($row['notice_date']); ?></td>
                            <td>
                                <a href="notice.php?delete=<?= $row['id']; ?>" onclick="return confirm('Delete this notice?');" class="btn btn-danger">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" style="text-align:center;">No notices found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
