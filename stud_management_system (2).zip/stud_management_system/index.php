<?php
session_start();
include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Gpts_Management_System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>


<div id="form">
    <h1>Student Management System</h1>

    <!-- 🔴 ERROR MESSAGE HERE -->
    <?php
    if (isset($_SESSION['error'])) {
        echo "<p style='color:red; text-align:center;'>" . $_SESSION['error'] . "</p>";
        unset($_SESSION['error']);
    }
    ?>

    <form action="login.php" method="POST">
        <label>Username:</label>
        <input type="text" name="user" required>
        <br><br>

        <label>Password:</label>
        <input type="password" name="pass" required>
        <br><br>

        <input type="submit" name="submit" id="btn" value="Login">
    </form>
</div>

</body>
</html>
