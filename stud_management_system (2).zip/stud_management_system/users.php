<?php
session_start();
include("connection.php");

// Session check
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$success = '';
$error = '';

// -------------------
// Delete User
// -------------------
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    $sql = "DELETE FROM users WHERE id=$id";
    if(mysqli_query($conn, $sql)){
        $success = "User deleted successfully!";
    } else {
        $error = "Error deleting user: " . mysqli_error($conn);
    }
}

// -------------------
// Add User
// -------------------
if(isset($_POST['add_user'])){
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // secure password

    $sql = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";
    if(mysqli_query($conn, $sql)){
        $success = "User added successfully!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// -------------------
// Fetch all users
// -------------------
$users = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Users Management</title>
<link rel="stylesheet" href="users.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<div class="main">
    <h2 class="page-title">👤 Users Management</h2>

    <!-- Messages -->
    <?php if($success) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if($error) echo "<div class='alert alert-error'>$error</div>"; ?>

    <!-- Add User Form -->
    <div class="user-card">
        <h3>Add New User</h3>
        <form method="post" class="user-form">
            <label>Username</label>
            <input type="text" name="username" placeholder="Enter Username" required>

            <label>Password</label>
            <input type="password" name="password" placeholder="Enter Password" required>

            <button type="submit" name="add_user">
                <i class="fas fa-plus"></i> Add User
            </button>
        </form>
    </div>

    <!-- Users Table -->
    <div class="user-card">
        <h3>User List</h3>
        <table class="user-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($users) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($users)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']); ?></td>
                            <td><?= htmlspecialchars($row['username']); ?></td>
                            <td>
                                <a href="users.php?delete=<?= $row['id']; ?>" onclick="return confirm('Delete this user?');" class="btn btn-danger">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" style="text-align:center;">No users found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
