<?php
session_start();
include("connection.php");

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// DELETE teacher
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM student_teacher WHERE id=$id");
    header("Location: /stud_management_system/teachers.php?msg=deleted");
    exit();
}

// ADD teacher
if (isset($_POST['add_teacher'])) {
    $name    = mysqli_real_escape_string($conn, $_POST['name']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $phone   = mysqli_real_escape_string($conn, $_POST['phone']);
    $email   = mysqli_real_escape_string($conn, $_POST['email']);

    mysqli_query(
        $conn,
        "INSERT INTO student_teacher (name, subject, phone, email)
         VALUES ('$name','$subject','$phone','$email')"
    );
    header("Location: /stud_management_system/teachers.php?msg=added");
    exit();
}

$teachers = mysqli_query($conn, "SELECT * FROM student_teacher ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Teachers</title>
    <link rel="stylesheet" href="css/teacher.css">
</head>
<body>

<h2>Teachers Management</h2>

<?php if (isset($_GET['msg']) && $_GET['msg'] == 'added'): ?>
    <p style="color:green;">Teacher added successfully</p>
<?php endif; ?>

<?php if (isset($_GET['msg']) && $_GET['msg'] == 'deleted'): ?>
    <p style="color:red;">Teacher deleted successfully</p>
<?php endif; ?>

<!-- ADD FORM -->
<form method="post">
    <input type="text" name="name" placeholder="Teacher Name" required>
    <input type="text" name="subject" placeholder="Subject" required>
    <input type="text" name="phone" placeholder="Phone" required>
    <input type="email" name="email" placeholder="Email" required>
    <button type="submit" name="add_teacher">Add Teacher</button>
</form>

<br>

<!-- TABLE -->
<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Subject</th>
        <th>Phone</th>
        <th>Email</th>
        <th>Action</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($teachers)) { ?>
    <tr>
        <td><?= $row['id']; ?></td>
        <td><?= $row['name']; ?></td>
        <td><?= $row['subject']; ?></td>
        <td><?= $row['phone']; ?></td>
        <td><?= $row['email']; ?></td>
        <td>
            <a href="/stud_management_system/teachers.php?delete=<?= $row['id']; ?>"
               onclick="return confirm('Delete teacher?');">
               Delete
            </a>
        </td>
    </tr>
    <?php } ?>
</table>

</body>
</html>
