<?php
session_start();
include("connection.php");

// Session check
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$success = '';
$error = '';

// -------------------
// Delete Exam
// -------------------
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    $sql = "DELETE FROM exam WHERE id=$id";
    if(mysqli_query($conn, $sql)){
        $success = "Exam deleted successfully!";
    } else {
        $error = "Error deleting exam: " . mysqli_error($conn);
    }
}

// -------------------
// Add Exam
// -------------------
if(isset($_POST['add_exam'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $batch_id = (int)$_POST['batch_id'];
    $exam_date = mysqli_real_escape_string($conn, $_POST['exam_date']);

    $sql = "INSERT INTO exam (name, batch_id, exam_date) VALUES ('$name', '$batch_id', '$exam_date')";
    if(mysqli_query($conn, $sql)){
        $success = "Exam added successfully!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// -------------------
// Fetch all exams
// -------------------
$exams = mysqli_query($conn, "
    SELECT exam.id, exam.name, exam.exam_date, batch.name AS batch_name
    FROM exam
    LEFT JOIN batch ON exam.batch_id = batch.id
    ORDER BY exam.id DESC
");

// Fetch all batches for dropdown
$all_batches = mysqli_query($conn, "SELECT * FROM batch ORDER BY name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Exam Management</title>
<link rel="stylesheet" href="exam.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<div class="main">
    <h2 class="page-title">📝 Exam Management</h2>

    <!-- Messages -->
    <?php if($success) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if($error) echo "<div class='alert alert-error'>$error</div>"; ?>

    <!-- Add Exam Form -->
    <div class="exam-card">
        <h3>Add New Exam</h3>
        <form method="post" class="exam-form">
            <label>Exam Name</label>
            <input type="text" name="name" placeholder="Enter Exam Name" required>

            <label>Select Batch</label>
            <select name="batch_id" required>
                <option value="">-- Select Batch --</option>
                <?php while($batch = mysqli_fetch_assoc($all_batches)): ?>
                    <option value="<?= $batch['id']; ?>"><?= htmlspecialchars($batch['name']); ?></option>
                <?php endwhile; ?>
            </select>

            <label>Exam Date</label>
            <input type="date" name="exam_date" required>

            <button type="submit" name="add_exam">
                <i class="fas fa-plus"></i> Add Exam
            </button>
        </form>
    </div>

    <!-- Exams Table -->
    <div class="exam-card">
        <h3>Exam List</h3>
        <table class="exam-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Exam Name</th>
                    <th>Batch</th>
                    <th>Exam Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($exams) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($exams)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']); ?></td>
                            <td><?= htmlspecialchars($row['name']); ?></td>
                            <td><?= htmlspecialchars($row['batch_name']); ?></td>
                            <td><?= htmlspecialchars($row['exam_date']); ?></td>
                            <td>
                                <a href="exam.php?delete=<?= $row['id']; ?>" onclick="return confirm('Delete this exam?');" class="btn btn-danger">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" style="text-align:center;">No exams found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
