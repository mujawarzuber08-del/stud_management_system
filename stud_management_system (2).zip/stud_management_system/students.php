<?php
session_start();
include("connection.php");

// Redirect to login if not authenticated
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Add Student
if (isset($_POST['add_student'])) {
    $name  = trim($_POST['name']);
    $batch = trim($_POST['batch']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);

    // Prepared statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO student (name, batch, phone, email) VALUES (?, ?, ?, ?)");
    if(!$stmt){
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("ssss", $name, $batch, $phone, $email);
    $stmt->execute();
    $stmt->close();
}

// Delete Student
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']); // ensure id is integer
    $stmt = $conn->prepare("DELETE FROM student WHERE id = ?");
    if(!$stmt){
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Fetch all students
$students = $conn->query("SELECT * FROM student ORDER BY id ASC");
if(!$students){
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Management</title>
    
    <!-- Link to your CSS -->
    <link rel="stylesheet" href="students.css">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
<div class="main">

    <h2 class="page-title">👨‍🎓 Students Management</h2>

    <!-- Add Student Card -->
    <div class="student-card">
        <h3>Add New Student</h3>
        <form method="post" class="student-form">
            <input type="text" name="name" placeholder="Student Name" required>
            <input type="text" name="batch" placeholder="Batch" required>
            <input type="text" name="phone" placeholder="Phone Number" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <br>
            <button type="submit" name="add_student">
                <i class="fas fa-plus"></i> Add Student
            </button>
        </form>
    </div>

    <!-- Student Table -->
    <div class="student-card">
        <h3>Student List</h3>
        <table class="student-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Batch</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if($students->num_rows > 0): ?>
                    <?php while($row = $students->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']); ?></td>
                            <td><?= htmlspecialchars($row['name']); ?></td>
                            <td><?= htmlspecialchars($row['batch']); ?></td>
                            <td><?= htmlspecialchars($row['phone']); ?></td>
                            <td><?= htmlspecialchars($row['email']); ?></td>
                            <td>
                                <a href="students.php?delete=<?= $row['id']; ?>" 
                                   onclick="return confirm('Are you sure you want to delete this student?')" 
                                   class="btn btn-danger">
                                   <i class="fas fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align:center;">No students found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
</body>
</html>
